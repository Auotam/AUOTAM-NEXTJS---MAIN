const nextConfig = {
  reactStrictMode: true,
  output: 'standalone'
}

module.exports = nextConfig
